1. Refactoring routes and route handlers.
2. About Middleware, custom middleware.
3. Routers, routers mounting